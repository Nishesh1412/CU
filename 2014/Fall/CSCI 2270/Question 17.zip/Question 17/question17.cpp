#include <iostream>

using namespace std;

string convert_decimal_to_hex(int num)
{
	return "";
}


int main()
{
	cout << "16 converted to hexadecimal gives: " <<
		convert_decimal_to_hex(16) << endl;
	cout << "151 converted to hexadecimal gives: " <<
		convert_decimal_to_hex(151) << endl;
	cout << "0 converted to hexadecimal gives: " <<
		convert_decimal_to_hex(0) << endl;
}
